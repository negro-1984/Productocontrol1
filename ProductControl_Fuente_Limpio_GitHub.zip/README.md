# PRODUCT CONTROL — paquete inicial de 3 aplicaciones

Este paquete contiene tres proyectos fuente:
1. `server_windows/`: servidor central para Windows 10 (Python + FastAPI + SQLite).
2. `android_employee/`: aplicación Android para empleados.
3. `android_admin/`: aplicación Android administrativa con autenticación biométrica Android.

## Estado
Es una **base inicial de desarrollo**, no una versión de producción ni APK ya compiladas. Los proyectos Android requieren Android Studio/Gradle y pruebas en dispositivos reales. El servidor requiere instalación y pruebas en Windows.

## Arquitectura
- La base de datos central vive en el servidor activo (Windows o, en una fase posterior, teléfono Android administrador).
- Los teléfonos se conectan por la misma Wi-Fi local; no se requiere Internet para la LAN.
- Cada usuario tiene cuenta individual.
- El servidor asigna fecha/hora y registra cada operación en `audit_log`.
- Los empleados pueden registrar entradas, salidas y consultar inventario, pero no borrar movimientos.
- Las operaciones se registran como movimientos inmutables; una corrección se hace mediante reverso/ajuste auditado, nunca borrando el historial.
- La app administrativa solicita biometría con `BiometricPrompt`. Android conserva y verifica los datos biométricos; la app no lee ni guarda huellas/rostros.

## Seguridad importante
Esta base es para desarrollo en una red local de confianza. Antes de usarla con inventario real:
- configurar HTTPS/TLS o un túnel seguro en la LAN;
- implementar gestión robusta de sesiones/tokens, renovación y revocación;
- cambiar secretos y credenciales iniciales;
- aplicar roles y permisos en todos los endpoints;
- restringir el firewall de Windows a la red privada;
- cifrar y probar restauración de backups fuera del disco del servidor.
No exponer el servidor directamente a Internet.

## Servidor Windows
Requiere Python 3.11 o posterior.

```bat
cd server_windows
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn app:app --host 0.0.0.0 --port 8080
```

Abrir `http://IP_DEL_SERVIDOR:8080/docs` solo desde la LAN para probar la API.
La primera ejecución crea la base `data/product_control.db` y un usuario inicial:
- usuario: `admin`
- contraseña: `CambiarEstaClave123!`

**Cambie la contraseña inmediatamente.** Este usuario inicial es solo para pruebas.

## Android
Abrir cada carpeta Android como proyecto en Android Studio. Sustituir `SERVER_URL` en `ApiConfig.kt` por la dirección LAN del servidor, por ejemplo `http://192.168.1.20:8080/`.
La configuración HTTP sin cifrar está habilitada solo para facilitar pruebas locales. Para producción debe usarse HTTPS y quitar la excepción de cleartext.

## Alcance de esta entrega
Incluye estructura, autenticación básica de desarrollo, registro de productos/movimientos, auditoría y pantallas iniciales. Aún faltan módulos completos de transferencias entre almacenes, proveedores/clientes, exportaciones PDF/Excel, sincronización robusta/offline, administración integral y pruebas de seguridad.
