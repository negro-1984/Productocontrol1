package com.productcontrol.admin
object ApiConfig { const val SERVER_URL = "http://192.168.1.20:8080/" }
