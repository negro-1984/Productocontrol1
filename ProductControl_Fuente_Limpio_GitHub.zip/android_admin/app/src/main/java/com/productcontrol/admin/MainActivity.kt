package com.productcontrol.admin
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,28,28,28)}
        layout.addView(TextView(this).apply{text="PRODUCT CONTROL · ADMINISTRACIÓN";textSize=21f})
        status=TextView(this).apply{text="Panel administrativo protegido"};layout.addView(status)
        layout.addView(Button(this).apply{text="Desbloquear administración con biometría";setOnClickListener{authenticate()}})
        layout.addView(TextView(this).apply{text="Después de la verificación, esta app deberá iniciar sesión como administrador en el servidor. La biometría local no sustituye los permisos del servidor."})
        setContentView(layout)
    }
    private fun authenticate(){
        val manager=BiometricManager.from(this)
        val authenticators=BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if(manager.canAuthenticate(authenticators)!=BiometricManager.BIOMETRIC_SUCCESS){
            status.text="Configura huella/rostro o credencial de pantalla en Android";return
        }
        val prompt=BiometricPrompt(this,ContextCompat.getMainExecutor(this),object:BiometricPrompt.AuthenticationCallback(){
            override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){status.text="Biometría correcta. Falta validar la sesión y el rol administrador en el servidor."}
            override fun onAuthenticationError(errorCode:Int,errString:CharSequence){status.text="Autenticación cancelada: $errString"}
            override fun onAuthenticationFailed(){status.text="No se reconoció la biometría"}
        })
        val info=BiometricPrompt.PromptInfo.Builder().setTitle("Acceso de administrador")
            .setSubtitle("Confirma tu identidad para abrir Product Control")
            .setAllowedAuthenticators(authenticators).build()
        prompt.authenticate(info)
    }
}
