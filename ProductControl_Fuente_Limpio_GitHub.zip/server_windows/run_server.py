"""Entry point for the standalone Windows build of PRODUCT CONTROL."""
import os
import sys
from pathlib import Path

# Keep the SQLite database beside the executable, not in PyInstaller's temp folder.
BASE_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("PC_DB_PATH", str(DATA_DIR / "product_control.db"))

from app import app  # noqa: E402
import uvicorn  # noqa: E402

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PC_PORT", "8080")), log_level="info")
