import os, sqlite3, hashlib, secrets
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel, Field

DB_PATH = Path(os.getenv("PC_DB_PATH", "data/product_control.db"))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
app = FastAPI(title="PRODUCT CONTROL API", version="0.1.0")

def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c

def pw_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 310000).hex()
    return salt, digest

def init():
    with db() as c:
        c.executescript("""
        PRAGMA foreign_keys=ON;
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, full_name TEXT NOT NULL,
          password_salt TEXT NOT NULL, password_hash TEXT NOT NULL,
          role TEXT NOT NULL CHECK(role IN ('admin','employee')), active INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS warehouses(
          id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, active INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS products(
          id INTEGER PRIMARY KEY, sku TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
          unit TEXT NOT NULL DEFAULT 'unidad', cost REAL NOT NULL DEFAULT 0, price REAL NOT NULL DEFAULT 0,
          active INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS stock(
          product_id INTEGER NOT NULL REFERENCES products(id), warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
          quantity REAL NOT NULL DEFAULT 0, PRIMARY KEY(product_id, warehouse_id)
        );
        CREATE TABLE IF NOT EXISTS movements(
          id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
          product_id INTEGER NOT NULL REFERENCES products(id), warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
          kind TEXT NOT NULL CHECK(kind IN ('IN','OUT','ADJUSTMENT','REVERSAL')),
          quantity REAL NOT NULL CHECK(quantity > 0), before_qty REAL NOT NULL, after_qty REAL NOT NULL,
          note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit_log(
          id INTEGER PRIMARY KEY, user_id INTEGER, username TEXT NOT NULL, action TEXT NOT NULL,
          entity TEXT NOT NULL, entity_id TEXT, old_value TEXT, new_value TEXT, created_at TEXT NOT NULL
        );
        """)
        if not c.execute("SELECT 1 FROM users LIMIT 1").fetchone():
            username = os.getenv("PC_ADMIN_USER", "admin")
            password = os.getenv("PC_ADMIN_PASSWORD", "CambiarEstaClave123!")
            salt, digest = pw_hash(password)
            c.execute("INSERT INTO users(username,full_name,password_salt,password_hash,role) VALUES(?,?,?,?,?)",
                      (username, "Administrador inicial", salt, digest, "admin"))
        if not c.execute("SELECT 1 FROM warehouses LIMIT 1").fetchone():
            c.execute("INSERT INTO warehouses(name) VALUES('Almacén principal')")
init()

# Token simple de desarrollo. En producción reemplazar por OAuth2/JWT con expiración y revocación.
SESSIONS = {}
def current_user(authorization: Optional[str]):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Autenticación requerida")
    user = SESSIONS.get(authorization[7:])
    if not user:
        raise HTTPException(401, "Sesión inválida o reiniciada")
    return user

def admin_only(user):
    if user["role"] != "admin":
        raise HTTPException(403, "Permiso de administrador requerido")

def audit(c, user, action, entity, entity_id=None, old=None, new=None):
    c.execute("""INSERT INTO audit_log(user_id,username,action,entity,entity_id,old_value,new_value,created_at)
                 VALUES(?,?,?,?,?,?,?,?)""",
              (user["id"], user["username"], action, entity, str(entity_id or ""),
               str(old) if old is not None else None, str(new) if new is not None else None, now()))

class Login(BaseModel):
    username: str
    password: str
class ProductIn(BaseModel):
    sku: str = Field(min_length=1, max_length=80)
    name: str = Field(min_length=1, max_length=200)
    unit: str = "unidad"
    cost: float = 0
    price: float = 0
class MovementIn(BaseModel):
    product_id: int
    warehouse_id: int
    kind: str
    quantity: float = Field(gt=0)
    note: str = ""

@app.get("/api/health")
def health():
    return {"ok": True, "server_time": now(), "database": str(DB_PATH)}

@app.post("/api/login")
def login(data: Login):
    with db() as c:
        row = c.execute("SELECT * FROM users WHERE username=? AND active=1", (data.username,)).fetchone()
        if not row:
            raise HTTPException(401, "Credenciales incorrectas")
        _, digest = pw_hash(data.password, row["password_salt"])
        if not secrets.compare_digest(digest, row["password_hash"]):
            raise HTTPException(401, "Credenciales incorrectas")
        token = secrets.token_urlsafe(32)
        SESSIONS[token] = {"id": row["id"], "username": row["username"], "role": row["role"]}
        audit(c, SESSIONS[token], "LOGIN", "session", token[:8])
        return {"token": token, "username": row["username"], "role": row["role"]}

@app.get("/api/me")
def me(authorization: Optional[str] = Header(None)):
    return current_user(authorization)

@app.get("/api/products")
def products(authorization: Optional[str] = Header(None)):
    user = current_user(authorization)
    with db() as c:
        return [dict(r) for r in c.execute(
            "SELECT p.*, COALESCE(SUM(s.quantity),0) total_stock FROM products p LEFT JOIN stock s ON s.product_id=p.id WHERE p.active=1 GROUP BY p.id ORDER BY p.name")]

@app.post("/api/products")
def create_product(data: ProductIn, authorization: Optional[str] = Header(None)):
    user = current_user(authorization); admin_only(user)
    with db() as c:
        try:
            cur = c.execute("INSERT INTO products(sku,name,unit,cost,price) VALUES(?,?,?,?,?)",
                            (data.sku,data.name,data.unit,data.cost,data.price))
        except sqlite3.IntegrityError:
            raise HTTPException(409, "SKU ya existe")
        audit(c,user,"CREATE","product",cur.lastrowid,None,data.model_dump())
        return {"id":cur.lastrowid}

@app.get("/api/warehouses")
def warehouses(authorization: Optional[str] = Header(None)):
    current_user(authorization)
    with db() as c:
        return [dict(r) for r in c.execute("SELECT * FROM warehouses WHERE active=1 ORDER BY name")]

@app.post("/api/warehouses")
def create_warehouse(data: dict, authorization: Optional[str] = Header(None)):
    user=current_user(authorization); admin_only(user)
    name=str(data.get("name","")).strip()
    if not name: raise HTTPException(400,"Nombre requerido")
    with db() as c:
        cur=c.execute("INSERT INTO warehouses(name) VALUES(?)",(name,))
        audit(c,user,"CREATE","warehouse",cur.lastrowid,None,{"name":name})
        return {"id":cur.lastrowid}

@app.post("/api/movements")
def create_movement(data: MovementIn, authorization: Optional[str] = Header(None)):
    user=current_user(authorization)
    if data.kind not in ("IN","OUT"):
        raise HTTPException(400,"Tipo permitido: IN u OUT")
    with db() as c:
        if not c.execute("SELECT 1 FROM products WHERE id=? AND active=1",(data.product_id,)).fetchone():
            raise HTTPException(404,"Producto no encontrado")
        if not c.execute("SELECT 1 FROM warehouses WHERE id=? AND active=1",(data.warehouse_id,)).fetchone():
            raise HTTPException(404,"Almacén no encontrado")
        row=c.execute("SELECT quantity FROM stock WHERE product_id=? AND warehouse_id=?",
                      (data.product_id,data.warehouse_id)).fetchone()
        before=float(row["quantity"]) if row else 0.0
        after=before + data.quantity if data.kind=="IN" else before - data.quantity
        if after < 0: raise HTTPException(409,"Existencias insuficientes")
        c.execute("""INSERT INTO stock(product_id,warehouse_id,quantity) VALUES(?,?,?)
                     ON CONFLICT(product_id,warehouse_id) DO UPDATE SET quantity=excluded.quantity""",
                  (data.product_id,data.warehouse_id,after))
        cur=c.execute("""INSERT INTO movements(user_id,product_id,warehouse_id,kind,quantity,before_qty,after_qty,note,created_at)
                         VALUES(?,?,?,?,?,?,?,?,?)""",
                      (user["id"],data.product_id,data.warehouse_id,data.kind,data.quantity,before,after,data.note,now()))
        audit(c,user,data.kind,"movement",cur.lastrowid,{"quantity":before},{"quantity":after,"delta":data.quantity})
        return {"movement_id":cur.lastrowid,"before":before,"after":after,"server_time":now()}

@app.get("/api/audit")
def audit_list(authorization: Optional[str] = Header(None), limit: int = 200):
    user=current_user(authorization); admin_only(user)
    with db() as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM audit_log ORDER BY id DESC LIMIT ?",(max(1,min(limit,1000)),))]

@app.get("/api/movements")
def movement_list(authorization: Optional[str] = Header(None), limit: int = 200):
    current_user(authorization)
    with db() as c:
        return [dict(r) for r in c.execute(
            """SELECT m.*,u.username,p.sku,p.name product,w.name warehouse
               FROM movements m JOIN users u ON u.id=m.user_id JOIN products p ON p.id=m.product_id
               JOIN warehouses w ON w.id=m.warehouse_id ORDER BY m.id DESC LIMIT ?""",
            (max(1,min(limit,1000)),))]
