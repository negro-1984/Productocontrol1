@echo off
cd /d %~dp0
if not exist .venv\Scripts\python.exe python -m venv .venv
call .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8080
pause
