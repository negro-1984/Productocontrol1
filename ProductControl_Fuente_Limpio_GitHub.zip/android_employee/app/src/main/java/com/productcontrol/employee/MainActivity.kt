package com.productcontrol.employee
import android.app.Activity
import android.os.Bundle
import android.widget.*
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class MainActivity : Activity() {
    private val client = OkHttpClient()
    private var token: String? = null
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,28,28,28) }
        layout.addView(TextView(this).apply { text="PRODUCT CONTROL · EMPLEADO"; textSize=22f })
        val server = EditText(this).apply { setText(ApiConfig.SERVER_URL); hint="URL del servidor" }; layout.addView(server)
        val user = EditText(this).apply { hint="Usuario" }; layout.addView(user)
        val pass = EditText(this).apply { hint="Contraseña"; inputType=129 }; layout.addView(pass)
        status=TextView(this); layout.addView(status)
        layout.addView(Button(this).apply { text="Iniciar sesión"; setOnClickListener {
            val body=JSONObject().put("username",user.text.toString()).put("password",pass.text.toString())
            val req=Request.Builder().url(server.text.toString().trimEnd('/')+"/api/login")
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            client.newCall(req).enqueue(object:Callback{
                override fun onFailure(call:Call,e:IOException){runOnUiThread{status.text="No se pudo conectar: ${e.message}"}}
                override fun onResponse(call:Call,response:Response){val text=response.body?.string().orEmpty()
                    runOnUiThread { if(response.isSuccessful){token=JSONObject(text).getString("token");status.text="Sesión iniciada. Ya puedes registrar operaciones."}else status.text="Acceso rechazado: $text" }
                }
            })
        }})
        layout.addView(Button(this).apply { text="Consultar productos"; setOnClickListener { apiGet("api/products") } })
        layout.addView(Button(this).apply { text="Ver movimientos"; setOnClickListener { apiGet("api/movements") } })
        setContentView(ScrollView(this).apply { addView(layout) })
    }
    private fun apiGet(path:String){
        val t=token ?: run { status.text="Inicia sesión primero"; return }
        val req=Request.Builder().url(ApiConfig.SERVER_URL+path).header("Authorization","Bearer $t").build()
        client.newCall(req).enqueue(object:Callback{
            override fun onFailure(call:Call,e:IOException){runOnUiThread{status.text=e.message}}
            override fun onResponse(call:Call,response:Response){val body=response.body?.string().orEmpty();runOnUiThread{status.text=body}}
        })
    }
}
